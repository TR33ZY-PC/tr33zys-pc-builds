TR33ZY'S PC BUILDS — FREE STATIC WEBSITE

Files:
- index.html
- style.css

Before publishing:
1. Open index.html.
2. Search for YOUR-EMAIL@example.com and replace it with the business email.
3. Upload index.html and style.css to a free static host such as GitHub Pages.

The quote form uses mailto, so it does not require a paid form service.
